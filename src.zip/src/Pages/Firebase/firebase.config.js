const firebaseConfig = {
    apiKey: "AIzaSyC9lBrjTxa3zwne5HZj0lItpgX_LzCOGrY",
    authDomain: "turista-18a4c.firebaseapp.com",
    projectId: "turista-18a4c",
    storageBucket: "turista-18a4c.appspot.com",
    messagingSenderId: "813223529289",
    appId: "1:813223529289:web:f38a7ba2e820886dc5e898"
};

export default firebaseConfig;